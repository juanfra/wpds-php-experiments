<?php
/**
 * Renders `@wordpress/ui` components on server-rendered admin screens.
 *
 * The public contract is `render( $name, $props )`: a component name and
 * props in, HTML out. The props each component accepts are declared in
 * `packages/ui/php/<name>/component.json`. The markup and class names are not
 * part of the contract and change with `@wordpress/ui`.
 *
 * The markup comes from `packages/ui/build-php/manifest.php`, which the build
 * generates by rendering the React components: a base render, what each
 * variant value changes, and full snapshots for the combinations those
 * changes can't rebuild, with placeholders for the free-form props. Rendering
 * applies the changes and fills in the placeholders, so there is no markup
 * to maintain here.
 *
 * @package gutenberg
 */

/**
 * Server-rendered `@wordpress/ui` components, loaded from the generated manifest.
 */
final class Gutenberg_UI_Components {

	/**
	 * Directory of the build output, with a trailing slash.
	 *
	 * @var string
	 */
	private $dir;

	/**
	 * URL of the build output, with a trailing slash.
	 *
	 * @var string
	 */
	private $url;

	/**
	 * The generated manifest, or null when it hasn't been built.
	 *
	 * @var array|null
	 */
	private $manifest;

	/**
	 * Prefix of the asset handles.
	 *
	 * @var string
	 */
	private $prefix;

	/**
	 * Constructor.
	 *
	 * A plugin that bundles its own copy of the build output passes its own
	 * prefix, so its stylesheet loads next to core's instead of replacing it
	 * or being skipped.
	 *
	 * @param string $dir    Directory of the build output.
	 * @param string $url    URL of the build output.
	 * @param string $prefix Optional. Prefix of the asset handles. Default 'wp-ui-'.
	 */
	public function __construct( $dir, $url, $prefix = 'wp-ui-' ) {
		$this->dir    = trailingslashit( $dir );
		$this->url    = trailingslashit( $url );
		$this->prefix = $prefix;

		$manifest       = $this->dir . 'manifest.php';
		$this->manifest = is_readable( $manifest ) ? require $manifest : null;
	}

	/**
	 * Whether the build output is available.
	 *
	 * @return bool
	 */
	public function is_available() {
		return is_array( $this->manifest );
	}

	/**
	 * Returns a component's props and variants, as declared in its `component.json`.
	 *
	 * @param string $name Component name.
	 * @return array|null Component metadata, or null if there's no such component.
	 */
	public function get_component_metadata( $name ) {
		if ( ! is_string( $name ) || ! isset( $this->manifest['components'][ $name ] ) ) {
			return null;
		}

		return $this->manifest['components'][ $name ];
	}

	/**
	 * Registers the stylesheet.
	 *
	 * Screens that render components should enqueue it in the head with
	 * `enqueue_assets()`; otherwise `render()` enqueues it late, and it prints
	 * in the footer.
	 */
	public function register_assets() {
		if ( ! $this->is_available() ) {
			return;
		}

		$version = $this->manifest['version'] . '-' . filemtime( $this->dir . 'manifest.php' );

		wp_register_style( $this->prefix . 'components', $this->url . 'style.css', array( 'wp-theme' ), $version );

		if ( is_readable( $this->dir . 'hydrate.js' ) ) {
			wp_register_script(
				$this->prefix . 'hydrate',
				$this->url . 'hydrate.js',
				array( 'react', 'react-dom', 'react-jsx-runtime' ),
				$version,
				array( 'in_footer' => true )
			);
		}
	}

	/**
	 * Enqueues the stylesheet.
	 */
	public function enqueue_assets() {
		if ( ! $this->is_available() ) {
			return;
		}

		// Rendering can happen before `admin_enqueue_scripts`.
		if ( ! wp_style_is( $this->prefix . 'components', 'registered' ) ) {
			$this->register_assets();
		}
		wp_enqueue_style( $this->prefix . 'components' );
	}

	/**
	 * Renders a component.
	 *
	 * Props are checked against the component's schema. An unknown prop is
	 * dropped, and an invalid value falls back to the default, each with a
	 * `_doing_it_wrong()` notice, so callers find mistakes without breaking
	 * the screen.
	 *
	 * Content is escaped unless it's known to be safe. See `get_safe_content()`
	 * for what a component accepts as content.
	 *
	 * @param string $name    Component name, e.g. `button`.
	 * @param array  $props   Component props.
	 * @param mixed  $content Optional. Content, for components that accept it.
	 * @return Gutenberg_UI_Safe_HTML Component HTML, empty if it can't be rendered.
	 */
	public function render( $name, $props = array(), $content = null ) {
		$component = $this->get_component_metadata( $name );
		if ( ! $component ) {
			$this->doing_it_wrong(
				/* translators: %s: Component name. */
				sprintf( __( 'Unknown component "%s".', 'gutenberg' ), $name )
			);
			return Gutenberg_UI_Safe_HTML::trusted( '' );
		}

		if ( null !== $content && empty( $component['content'] ) ) {
			$this->doing_it_wrong(
				/* translators: %s: Component name. */
				sprintf( __( 'The "%s" component doesn\'t accept content.', 'gutenberg' ), $name )
			);
			$content = null;
		}

		$props = $this->validate_props( $name, $component['props'], (array) $props );
		if ( null === $props ) {
			return Gutenberg_UI_Safe_HTML::trusted( '' );
		}

		$this->enqueue_assets();

		// IDs React generates connect parts of a component, like a trigger to
		// the panel it controls. Make them unique, so two components on a page
		// don't point at each other's parts.
		$id_prefix = wp_unique_id( 'wp-ui-' ) . '-';
		$content   = $this->get_safe_content( $content );

		if ( ! empty( $component['fallback'] ) ) {
			// Rendered by React in the browser, which replaces the fallback.
			$html = 'radio' === $component['fallback']
				? $this->get_native_radios( $props )
				: $this->get_native_select( $props, $id_prefix );
		} else {
			// The markup is generated from React and every value in it is escaped
			// for its context, so the result is safe to insert into another component.
			$markup = str_replace( '__wpuiid_', $id_prefix, $this->get_markup( $component, $props ) );
			$html   = $this->trim_class_names( $this->fill_placeholders( $markup, $props, $content ) );
		}

		if ( ! empty( $component['interactive'] ) ) {
			$html = $this->add_island( $component, $props, $content, $id_prefix, $html );
		}

		return Gutenberg_UI_Safe_HTML::trusted( $html );
	}

	/**
	 * Lets React hydrate an interactive component in the browser.
	 *
	 * Wraps the markup in a `<wp-ui-island>` with what `hydrate.js` needs to
	 * render the same element again: the component's mapping, its props, its
	 * content and the ID prefix. React then attaches the component's own
	 * behavior to the markup instead of replacing it.
	 *
	 * @param array  $component Component metadata.
	 * @param array  $props     Validated props.
	 * @param string $content   Safe HTML for the content.
	 * @param string $id_prefix Prefix used for generated IDs.
	 * @param string $html      Component HTML.
	 * @return string HTML.
	 */
	private function add_island( $component, $props, $content, $id_prefix, $html ) {
		wp_enqueue_script( $this->prefix . 'hydrate' );

		return sprintf(
			'<wp-ui-island style="display:contents" data-island="%s" data-content="%s" data-id-prefix="%s">%s</wp-ui-island>',
			esc_attr(
				wp_json_encode(
					array_filter(
						array(
							'render'   => $component['render'],
							'props'    => $props,
							'fallback' => $component['fallback'] ?? null,
							'value'    => $component['value'] ?? null,
						),
						static function ( $value ) {
							return null !== $value;
						}
					)
				)
			),
			esc_attr( $content ),
			esc_attr( $id_prefix ),
			$html
		);
	}

	/**
	 * Tidies the spaces an empty class name prop leaves in `class` attributes.
	 *
	 * React joins class names without the empty ones, and hydration compares
	 * the attribute exactly, so `class=" a"` doesn't match `class="a"`.
	 *
	 * @param string $html Component HTML.
	 * @return string HTML.
	 */
	private function trim_class_names( $html ) {
		$processor = new WP_HTML_Tag_Processor( $html );
		while ( $processor->next_tag() ) {
			$class = $processor->get_attribute( 'class' );
			if ( is_string( $class ) ) {
				$trimmed = trim( preg_replace( '/\s+/', ' ', $class ) );
				if ( $trimmed !== $class ) {
					$processor->set_attribute( 'class', $trimmed );
				}
			}
		}
		return $processor->get_updated_html();
	}

	/**
	 * Prints a native `<select>` for a component React renders in the browser.
	 *
	 * It posts the same field as the component, so the form works before
	 * JavaScript loads, or without it. A list value (`name="x[]"`) gets a
	 * multiple select.
	 *
	 * @param array  $props     Validated props: `label`, `name`, `items` (or
	 *                          groups of them) and `value`.
	 * @param string $id_prefix Prefix for the select's ID.
	 * @return string HTML.
	 */
	private function get_native_select( $props, $id_prefix ) {
		$selected = array_map( 'strval', (array) $props['value'] );
		$multiple = is_array( $props['value'] );
		$id       = $id_prefix . 'select';

		$option = static function ( $item ) use ( $selected ) {
			return sprintf(
				'<option value="%s"%s%s>%s</option>',
				esc_attr( $item['value'] ),
				selected( in_array( (string) $item['value'], $selected, true ), true, false ),
				disabled( ! empty( $item['disabled'] ), true, false ),
				esc_html( $item['label'] )
			);
		};

		$options = '';
		$found   = false;
		foreach ( $props['items'] as $item ) {
			if ( isset( $item['items'] ) ) {
				$options .= sprintf( '<optgroup label="%s">', esc_attr( $item['label'] ) );
				foreach ( $item['items'] as $group_item ) {
					$options .= $option( $group_item );
					$found    = $found || in_array( (string) $group_item['value'], $selected, true );
				}
				$options .= '</optgroup>';
				continue;
			}
			$options .= $option( $item );
			$found    = $found || in_array( (string) $item['value'], $selected, true );
		}

		// Without a selected item, a single select posts its first option.
		// An empty one keeps it posting nothing, like the component.
		if ( ! $multiple && ! $found ) {
			$options = '<option value=""></option>' . $options;
		}

		return sprintf(
			'<div class="wp-ui-fallback"><label for="%1$s">%2$s</label> <select id="%1$s" name="%3$s"%4$s>%5$s</select></div>',
			esc_attr( $id ),
			esc_html( $props['label'] ),
			esc_attr( $props['name'] ),
			$multiple ? ' multiple' : '',
			$options
		);
	}

	/**
	 * Prints native radio buttons for a component React renders in the browser.
	 *
	 * @param array $props Validated props: `label`, `name`, `items` and `value`.
	 * @return string HTML.
	 */
	private function get_native_radios( $props ) {
		$radios = '';
		foreach ( $props['items'] as $item ) {
			$radios .= sprintf(
				'<label><input type="radio" name="%s" value="%s"%s%s /> %s</label><br />',
				esc_attr( $props['name'] ),
				esc_attr( $item['value'] ),
				checked( (string) $item['value'], (string) $props['value'], false ),
				disabled( ! empty( $item['disabled'] ), true, false ),
				esc_html( $item['label'] )
			);
		}

		return sprintf(
			'<fieldset class="wp-ui-fallback"><legend>%s</legend>%s</fieldset>',
			esc_html( $props['label'] ),
			$radios
		);
	}

	/**
	 * Turns content into HTML that is safe to insert.
	 *
	 * - A string, or anything else that prints, is escaped. It shows as text.
	 * - `Gutenberg_UI_Safe_HTML`, such as another component's output, is
	 *   inserted as HTML.
	 * - A closure is called and what it prints is inserted as HTML, as in any
	 *   template: the closure escapes its own values. What it returns follows
	 *   these same rules, so returning another component works too.
	 * - An array is a list of any of the above.
	 *
	 * @param mixed $content Content.
	 * @return string Safe HTML.
	 */
	private function get_safe_content( $content ) {
		if ( null === $content ) {
			return '';
		}
		if ( $content instanceof Gutenberg_UI_Safe_HTML ) {
			return (string) $content;
		}
		// Only closures are called, never strings that happen to name a function.
		if ( $content instanceof Closure ) {
			ob_start();
			try {
				$returned = $content();
			} finally {
				$output = (string) ob_get_clean();
			}
			return $output . $this->get_safe_content( $returned );
		}
		if ( is_array( $content ) ) {
			return implode( '', array_map( array( $this, 'get_safe_content' ), $content ) );
		}
		if ( is_scalar( $content ) || ( is_object( $content ) && method_exists( $content, '__toString' ) ) ) {
			return self::esc_plain_text( (string) $content );
		}
		return '';
	}

	/**
	 * Builds the key of the snapshot for the given props.
	 *
	 * @param array $component Component metadata.
	 * @param array $props     Validated props.
	 * @return string Snapshot key.
	 */
	private function get_snapshot_key( $component, $props ) {
		$key = array();
		foreach ( $component['variants'] as $prop ) {
			$value = $props[ $prop ];
			// For optional text, whether it's set is the variant.
			if ( ! empty( $component['props'][ $prop ]['optional'] ) ) {
				$value = '' !== $value;
			}
			$key[] = $prop . '=' . ( is_bool( $value ) ? ( $value ? 'true' : 'false' ) : $value );
		}

		return implode( '&', $key );
	}

	/**
	 * Builds the markup for the given props, with placeholders still in it.
	 *
	 * Starts from the base render and applies what each variant value
	 * changes: classes, attributes and inline styles, per tag. Combinations
	 * those changes can't rebuild, such as a variant that swaps an icon, are
	 * stored as full snapshots instead. The build checks every combination, so
	 * this always matches what React renders.
	 *
	 * @param array $component Component metadata.
	 * @param array $props     Validated props.
	 * @return string Markup with placeholders.
	 */
	private function get_markup( $component, $props ) {
		$key = $this->get_snapshot_key( $component, $props );
		if ( isset( $component['exceptions'][ $key ] ) ) {
			return $component['exceptions'][ $key ];
		}

		$changes_by_tag = array();
		foreach ( explode( '&', $key ) as $variant ) {
			foreach ( $component['changes'][ $variant ] ?? array() as $change ) {
				$changes_by_tag[ $change['tag'] ][] = $change;
			}
		}
		if ( ! $changes_by_tag ) {
			return $component['base'];
		}

		$processor = new WP_HTML_Tag_Processor( $component['base'] );
		$tag       = -1;
		while ( $processor->next_tag() ) {
			++$tag;
			foreach ( $changes_by_tag[ $tag ] ?? array() as $change ) {
				foreach ( $change['removeClass'] ?? array() as $class_name ) {
					$processor->remove_class( $class_name );
				}
				foreach ( $change['addClass'] ?? array() as $class_name ) {
					$processor->add_class( $class_name );
				}
				if ( isset( $change['style'] ) ) {
					$processor->set_attribute( 'style', $this->change_style( (string) $processor->get_attribute( 'style' ), $change['style'] ) );
				}
				foreach ( $change['set'] ?? array() as $name => $value ) {
					$processor->set_attribute( $name, $value );
				}
				foreach ( $change['remove'] ?? array() as $name ) {
					$processor->remove_attribute( $name );
				}
			}
		}

		return $processor->get_updated_html();
	}

	/**
	 * Sets or removes declarations in an inline style.
	 *
	 * @param string $style   Inline style.
	 * @param array  $changes Value per property, or null to remove it.
	 * @return string Inline style.
	 */
	private function change_style( $style, $changes ) {
		$declarations = array();
		foreach ( array_filter( explode( ';', $style ) ) as $declaration ) {
			list( $property, $value )          = array_pad( explode( ':', $declaration, 2 ), 2, '' );
			$declarations[ trim( $property ) ] = trim( $value );
		}
		foreach ( $changes as $property => $value ) {
			if ( null === $value ) {
				unset( $declarations[ $property ] );
			} else {
				$declarations[ $property ] = $value;
			}
		}

		$style = array();
		foreach ( $declarations as $property => $value ) {
			$style[] = $property . ':' . $value;
		}
		return implode( ';', $style );
	}

	/**
	 * Fills in the slots of the markup.
	 *
	 * Each placeholder says where it is, such as `__wpuislot_label__text__`
	 * or `__wpuislot_type__attr_type__`, so it's escaped for that context.
	 * Everything is replaced in one pass, so filled-in values, content
	 * included, are never read as placeholders themselves.
	 *
	 * @param string $markup  Markup with placeholders.
	 * @param array  $props   Validated props.
	 * @param string $content Safe HTML for the content.
	 * @return string Component HTML.
	 */
	private function fill_placeholders( $markup, $props, $content ) {
		return preg_replace_callback(
			'/__wpuislot_([a-z0-9_]+?)__(?:attr_([a-z0-9-]+)|text)__/',
			static function ( $placeholder ) use ( $props, $content ) {
				$prop      = $placeholder[1];
				$attribute = $placeholder[2] ?? '';

				// Already made safe by get_safe_content(). The build only allows it in text.
				if ( 'content' === $prop ) {
					return $content;
				}

				$value = (string) $props[ $prop ];
				if ( '' !== $attribute ) {
					// React blocks `javascript:` URLs; esc_url() does the same here.
					return in_array( $attribute, array( 'href', 'src', 'action', 'formaction' ), true ) ? esc_url( $value ) : self::esc_plain_text( $value );
				}
				return self::esc_plain_text( $value );
			},
			$markup
		);
	}

	/**
	 * Escapes plain text for HTML text or an attribute value, as React does.
	 *
	 * React escapes `&`, `<`, `>`, `"` and `'` in every string and never reads
	 * entities in it, so any entity a caller passes shows as written. Unlike
	 * `esc_html()` and `esc_attr()`, which leave existing entities alone, this
	 * does the same. Props are plain text: decode a string that is already
	 * HTML-encoded, such as the result of `get_the_title()`, first.
	 *
	 * @param string $text Plain text.
	 * @return string Escaped text.
	 */
	private static function esc_plain_text( $text ) {
		return htmlspecialchars( (string) $text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
	}

	/**
	 * Checks props against a component's schema and fills in defaults.
	 *
	 * @param string $name   Component name.
	 * @param array  $schema Prop schemas, keyed by prop name.
	 * @param array  $props  Props passed by the caller.
	 * @return array|null Props to render with, or null if a required prop is missing.
	 */
	private function validate_props( $name, $schema, $props ) {
		foreach ( array_keys( array_diff_key( $props, $schema ) ) as $prop ) {
			$this->doing_it_wrong(
				/* translators: 1: Prop name. 2: Component name. */
				sprintf( __( 'Unknown prop "%1$s" for the "%2$s" component.', 'gutenberg' ), $prop, $name )
			);
		}

		$validated = array();
		foreach ( $schema as $prop => $prop_schema ) {
			$is_required = ! empty( $prop_schema['required'] );

			if ( ! array_key_exists( $prop, $props ) ) {
				if ( $is_required ) {
					$this->doing_it_wrong(
						/* translators: 1: Prop name. 2: Component name. */
						sprintf( __( 'The "%1$s" prop is required for the "%2$s" component.', 'gutenberg' ), $prop, $name )
					);
					return null;
				}
				$validated[ $prop ] = $prop_schema['default'];
				continue;
			}

			$error = rest_validate_value_from_schema( $props[ $prop ], $prop_schema, $prop );
			if ( is_wp_error( $error ) ) {
				$this->doing_it_wrong(
					/* translators: 1: Component name. 2: Validation error. */
					sprintf( __( 'Invalid prop for the "%1$s" component: %2$s', 'gutenberg' ), $name, $error->get_error_message() )
				);
				if ( $is_required ) {
					return null;
				}
				$validated[ $prop ] = $prop_schema['default'];
				continue;
			}

			// Validation accepts `1` or `'true'` for a boolean; the snapshot key needs the real type.
			$validated[ $prop ] = rest_sanitize_value_from_schema( $props[ $prop ], $prop_schema, $prop );
		}

		return $validated;
	}

	/**
	 * Reports a mistake by the caller.
	 *
	 * @param string $message Message.
	 */
	private function doing_it_wrong( $message ) {
		_doing_it_wrong( __CLASS__ . '::render', esc_html( $message ), 'gutenberg-experimental' );
	}
}
